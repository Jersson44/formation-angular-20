import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'accueil',
    loadComponent: () => import('./application/home/home').then(m => m.Home)
  },
  {
    path: 'demandes-permis',
    loadComponent: () => import('./application/permit-application/pages/permit-application/permit-application').then(m => m.PermitApplicationPage)
  }
];
