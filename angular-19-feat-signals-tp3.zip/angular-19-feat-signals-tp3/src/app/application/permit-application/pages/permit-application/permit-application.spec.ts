import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PermitApplication } from './permit-application';

describe('PermitApplication', () => {
  let component: PermitApplication;
  let fixture: ComponentFixture<PermitApplication>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PermitApplication]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PermitApplication);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
