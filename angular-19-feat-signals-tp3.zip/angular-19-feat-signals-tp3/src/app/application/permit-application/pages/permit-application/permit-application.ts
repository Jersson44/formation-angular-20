import { Component } from '@angular/core';
import { PermitApplicationForm } from "../../components/permit-application-form/permit-application-form";

@Component({
  selector: 'app-permit-application-page',
  standalone: true,
  imports: [PermitApplicationForm],
  templateUrl: './permit-application.html',
  styleUrl: './permit-application.scss'
})
export class PermitApplicationPage {

}
