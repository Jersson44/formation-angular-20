import { Component, computed, effect, signal } from '@angular/core';

@Component({
  selector: 'app-permit-application-form',
  imports: [],
  templateUrl: './permit-application-form.html',
  styleUrl: './permit-application-form.scss',
})
export class PermitApplicationForm {
  motif = signal<string>('');
  readonly maxChars = 30;

  charsRestants = computed(() => this.calculCharsRestants());
  isMotifInvalid = signal<boolean>(true);
  private demandeSoumise = signal(false);

  constructor() {
    // utilisation des effets de bord pour notifier l'utilisateur.
    effect(() => this.notificationDemandeSoumise());
  }

  public onMotifChange(event: Event): void {
    const input = event?.target as HTMLInputElement;

    console.log(`-- 1 Motif modifié : ${this.motif()}}`);
    this.motif.set(input.value);
    console.log(
      `-- 2 Motif modifié : ${this.motif()}, caractères restants : ${this.charsRestants()}`
    );
    this.isMotifInvalid.set(
      this.motif().length == 0 || this.motif().length > this.maxChars
    );
  }

  public submitDemande(): void {
    console.log(`-- Soumission de la demande avec le motif : ${this.motif()}`);
    if (this.isMotifInvalid()) {
      console.error('-- Impossible de soumettre la demande : motif invalide');
      return;
    }
    // TODO : envoyer les données via une API.
    this.demandeSoumise.set(true);
  }

  private calculCharsRestants() {
    const remaining = this.maxChars - this.motif().length;
    console.log(`-- Calcul des caractères restants : ${remaining}`);
    return remaining;
  }

  private notificationDemandeSoumise() {
    if (this.demandeSoumise()) {
      console.log(`-- Notification : Votre demande a été soumise avec succès.`);
      console.log(`-- Demande soumise avec le motif : ${this.motif()}`);
    }
  }
}
