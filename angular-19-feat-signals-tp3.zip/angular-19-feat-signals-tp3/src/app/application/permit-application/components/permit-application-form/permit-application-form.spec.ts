import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PermitApplicationForm } from './permit-application-form';

describe('PermitApplicationForm', () => {
  let component: PermitApplicationForm;
  let fixture: ComponentFixture<PermitApplicationForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PermitApplicationForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PermitApplicationForm);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
