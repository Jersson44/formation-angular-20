# Plan d'Architecture pour l'Application Frontend Angular

Ce document décrit une architecture en couches simplifiée pour l'application frontend Angular, adaptée à la portée du projet et aux exercices.

**Domaines/Fonctionnalités Cibles :**
*   Gestion de demande de permis (Permit Application Management)
*   Affectation d’un véhicule à un agent administratif (Vehicle Assignment)
*   Supervision des demande de permis (Permit Supervision / Dashboard)

**I. Dossiers d'Architecture de Premier Niveau (`src/app/`)**

*   **`domain/`** : Définit les structures de données (types/interfaces) pour les entités métier principales. Allégé pour un contexte frontend.
*   **`application/`** : Contient le code Angular spécifique aux fonctionnalités, y compris les composants, les services de gestion d'état (avec les Signals), et la logique métier.
*   **`infrastructure/`** : Regroupe les éléments partagés non liés au domaine, les services utilitaires, les composants d'interface utilisateur réutilisables, et le layout global de l'application.

**II. Structure Détaillée des Dossiers**

**1. Couche Domaine (`src/app/domain/`)**
   *Objectif : Modèles de données/types pour chaque domaine métier.*

   ```
   src/app/domain/
   ├── permit-management/
   │   └── models/             # ex: permit-application.model.ts, applicant.model.ts
   ├── vehicle-assignment/
   │   └── models/             # ex: vehicle.model.ts, agent.model.ts
   └── permit-supervision/
       └── models/             # ex: supervision-case.model.ts, permit-status.model.ts
   ```

**2. Couche Application (`src/app/application/`)**
   *Objectif : Modules de fonctionnalités avec composants UI et services de logique/état.*

   ```
   src/app/application/
   ├── permit-application/     # Fonctionnalité : Gestion des demandes de permis
   │   ├── components/         # Composants UI (ex: permit-form, permit-list)
   │   ├── services/           # Services Angular pour l'état (Signals) & la logique
   │   └── models/             # (Optionnel) Modèles spécifiques à la vue ou structures de Signals affinées
   ├── vehicle-assignment/     # Fonctionnalité : Affectation de véhicule
   │   ├── components/
   │   ├── services/
   │   └── models/
   └── dashboard/              # Fonctionnalité : Supervision & Statistiques (liée au domaine permit-supervision)
       ├── components/
       ├── services/
       └── models/
   ```

**3. Couche Infrastructure (`src/app/infrastructure/`)**
   *Objectif : Utilitaires partagés, UI réutilisable, et squelette de l'application (layout).*

   ```
   src/app/infrastructure/
   ├── layout/                 # Contient le LayoutComponent principal et ses fichiers
   │   └── layout/             # (ex: layout.component.ts, .html, .scss)
   ├── ui/                     # Composants UI partagés et réutilisables (ex: boutons génériques, modales)
   │   └── components/
   ├── services/               # Services utilitaires partagés (ex: notification.service.ts)
   └── utils/                  # Fonctions utilitaires génériques (ex: formateurs de date)
   ```

**III. Fichiers Racine de l'Application**
   Les fichiers racine standards d'Angular (`app.component.ts`, `app.config.ts`, `app.routes.ts`, `main.ts`, `index.html`, `styles.scss`, etc.) restent à la racine de `src/app/` ou `src/` selon le cas.

**IV. Diagramme Mermaid de la Structure**

```mermaid
graph TD
    A[src/app] --> DOM(domain);
    A --> APP(application);
    A --> INFRA(infrastructure);
    A --> ROOT_FILES[app.config.ts, etc.];

    DOM --> DM_PM[permit-management];
    DOM --> DM_VA[vehicle-assignment];
    DOM --> DM_PS[permit-supervision];

    DM_PM --> DM_PM_MOD[models/];
    DM_VA --> DM_VA_MOD[models/];
    DM_PS --> DM_PS_MOD[models/];

    APP --> APP_PM[permit-application];
    APP --> APP_VA[vehicle-assignment];
    APP --> APP_DASH[dashboard];

    APP_PM --> APP_PM_COMP[components/];
    APP_PM --> APP_PM_SERV[services/];
    APP_PM --> APP_PM_MOD[models/];

    APP_VA --> APP_VA_COMP[components/];
    APP_VA --> APP_VA_SERV[services/];
    APP_VA --> APP_VA_MOD[models/];

    APP_DASH --> APP_DASH_COMP[components/];
    APP_DASH --> APP_DASH_SERV[services/];
    APP_DASH --> APP_DASH_MOD[models/];

    INFRA --> INFRA_LAYOUT[layout/];
    INFRA --> INFRA_UI[ui/];
    INFRA --> INFRA_SERV[services/];
    INFRA --> INFRA_UTILS[utils/];

    style DOM fill:#f9f,stroke:#333,stroke-width:2px;
    style APP fill:#ccf,stroke:#333,stroke-width:2px;
    style INFRA fill:#cfc,stroke:#333,stroke-width:2px;
