# Signals

---

## 🎯 Contexte professionnel

Vous travaillez pour le **Ministère de la Mobilité et des Transports**. L'objectif est de développer une application interne appelée **"TranspAdmin"**. Cette application permet de :

* gérer les demandes de permis de stationnement,
* suivre les affectations de véhicules administratifs,
* afficher des statistiques en temps réel.

La version Angular 19 est utilisée avec les **Angular Signals** pour simplifier et réactiver l’état.

---

## 📘 Concepts à illustrer (issus du blog Angular University)

* `signal()`
* `computed()`
* `effect()`
* `set()`, `update()`
* intégration avec le `async` pipe
* structuration de l’état avec `model signals`

---

## 🧩 Exercice 1 : Introduction aux Signals – Gestion d’une demande de permis

### 🎯 Objectif :

Créer un formulaire de demande de permis avec suivi en direct du nombre de caractères restants dans le champ "motif de la demande".

### 💡 Concepts utilisés :

* `signal()`
* `computed()`

### 📝 Enoncé :

1. Crée un signal `motif = signal('')`
2. Ajoute un `computed()` qui calcule les caractères restants (max 300).
3. Affiche dynamiquement ce compteur en bas du champ texte.

### ✅ Bonus :

* Griser le bouton de soumission si le champ est vide ou trop long (via `computed()`).

---

## 🧩 Exercice 2 : Effets secondaires – Notifications utilisateurs

### 🎯 Objectif :

Afficher une notification console dès qu'une nouvelle demande est soumise.

### 💡 Concepts utilisés :

* `effect()`

### 📝 Enoncé :

1. Crée un signal `demandeSoumise = signal(false)`
2. Utilise `effect()` pour afficher une notification dans la console à chaque changement à `true`.
3. Réinitialiser automatiquement à `false` après affichage (simulation via `setTimeout`).

---

## 🧩 Exercice 3 : Mise à jour de l’état – Affectation de véhicule

### 🎯 Objectif :

Simuler l’affectation d’un véhicule à un agent administratif.

### 💡 Concepts utilisés :

* `set()`, `update()`

### 📝 Enoncé :

1. Crée une structure `affectation = signal({ agent: '', vehicule: '' })`
2. Ajoute deux méthodes :

   * `changerAgent(nom: string)`
   * `changerVehicule(id: string)`
3. Affiche en temps réel la fiche d’affectation.

---

## 🧩 Exercice 4 : Signals + async pipe – Liste des permis en attente

### 🎯 Objectif :

Afficher une liste dynamique de permis en attente avec un filtre par type.

### 💡 Concepts utilisés :

* `signal()`, `computed()`
* Intégration avec `async` pipe dans le template

### 📝 Enoncé :

1. Crée un `signal` avec une liste de demandes `{ id, type, demandeur }`.
2. Crée un `signal` de filtre (`'résident'`, `'professionnel'`, `'visiteur'`)
3. Utilise un `computed()` pour filtrer les données.
4. Affiche le résultat via `async`.

---

## 🧩 Exercice 5 : Model Signals – Gestion centralisée d’état

### 🎯 Objectif :

Gérer l’état global d’un module : "Tableau de bord".

### 💡 Concepts utilisés :

* `model()` (ou structuration manuelle avec plusieurs `signal()`)
* Combinaison de `signal`, `computed`, `effect`

### 📝 Enoncé :

1. Crée une structure d’état :

   ```ts
   const dashboardState = {
     demandesEnCours: signal<number>(0),
     vehiculesDisponibles: signal<number>(0),
     utilisateursActifs: signal<number>(0),
     chargement: signal<boolean>(false)
   }
   ```
2. Ajoute un `computed()` pour détecter si les ressources sont "en surcharge" (ex : < 5 véhicules disponibles ET > 100 demandes).
3. Utilise un `effect()` pour afficher une alerte console si surcharge détectée.

---

## 📦 Bonus – Exercice complet

### 🎯 Objectif :

Créer un composant `gestion-demandes` avec :

* Formulaire de demande,
* Liste en temps réel,
* Filtres,
* Notification de soumission.

Combine les éléments vus précédemment dans une petite app modulaire.

---

Souhaitez-vous que je vous fournisse les **solutions types** ou les **structures de fichiers Angular** pour ces exercices ?
