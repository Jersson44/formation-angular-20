import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Layout } from "./infrastructure/layout/layout/layout";

@Component({
  selector: 'app-root',
  imports: [Layout],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected title = 'formation-angular';
}
