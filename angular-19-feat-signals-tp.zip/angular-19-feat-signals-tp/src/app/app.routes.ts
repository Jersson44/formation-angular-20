import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'accueil',
    loadComponent: () => import('./application/home/home').then(m => m.Home)
  }
];
