# Signals

---

## 🎯 Contexte professionnel

Vous travaillez pour le **Ministère de la Mobilité et des Transports**. L'objectif est de développer une application interne appelée **"TranspAdmin"**. Cette application permet de :

* gérer les demandes de permis,
* suivre les affectations de véhicules administratifs,
* afficher des statistiques en temps réel.

La version Angular 20 est utilisée avec les **Angular Signals** pour simplifier et réactiver l’état.

---

## 📘 Concepts à illustrer (issus du blog Angular University)

* `environment`
* `providers`
* `useClass`
* `factory`


---

## 🧩 Exercice 1 : Implémenter plusieurs Services de LOG

### 🎯 Objectif :

Utiliser un service de LOG sur un composants spécifique

### 💡 Concepts utilisés :

* `chargement par class`
* `useClass`

### 📝 Enoncé :

1.  **Générer les fichiers d'environnement**
    -   Utilise la commande `ng generate environments` pour créer les fichiers `environment.ts` et `environment.production.ts`.
    -   Configure `angular.json` pour utiliser ces fichiers lors du build en mode `development` ou `production` en ajoutant la section `fileReplacements`.

2.  **Créer une interface de Logger**
    -   Crée une interface `Logger` dans `src/app/infrastructure/interfaces/logger.ts` qui définit une méthode `log(message: string)`.

3.  **Créer les implémentations du Logger**
    -   Crée trois services qui implémentent l'interface `Logger` :
        -   `LoggerService` : Le service de base.
        -   `DevLoggerService` : Un service qui préfixe les logs avec `[DEV]`.
        -   `ProdLoggerService` : Un service qui préfixe les logs avec `[PROD]`.

4.  **Fournir le Logger au niveau d'un composant**
    -   Dans le composant `SupervisionComponent` (`supervision.ts`), utilise le tableau `providers` pour injecter une implémentation spécifique du logger.
    -   Utilise la syntaxe `useClass` pour dire à Angular : "Quand je demande `LoggerService`, utilise en fait `ProdLoggerService`".
        ```ts
        providers: [
          { provide: xxx, useClass: xxxxxxxx }
        ]
        ```

5.  **Utiliser le Logger**
    -   Injecte `LoggerService` dans le `SupervisionComponent`.
    -   Appelle la méthode `log()` pour enregistrer un message.
    -   Observe que, bien que tu aies injecté `LoggerService`, c'est bien le `ProdLoggerService` qui est utilisé, affichant `[PROD]` dans la console, grâce à la configuration du `provider` au niveau du composant.


## 🧩 Exercice 2 : Utiliser une implémentation de l'interface LOGGER

### 🎯 Objectif :

Utiliser une implémentation du service de LOG sur un composants spécifique à partir du injection par token pour utiliser l'interface à la place d'une classe.

### 💡 Concepts utilisés :

* `chargement par InjectionToken`
* `useClass`

### 📝 Enoncé :

1.  **Créer un `InjectionToken`**
    -   Dans le fichier `src/app/infrastructure/interfaces/logger.ts`, crée un `InjectionToken` qui sera utilisé pour injecter le service de logging.
        ```ts
        . . .

        export const LOGGER_TOKEN = new InjectionToken<Logger>('LoggerToken');
        ```

2.  **Fournir le Logger avec le Token**
    -   Dans le composant `SupervisionComponent` (`supervision.ts`), modifie le `provider` pour utiliser le `LOGGER_TOKEN` au lieu de la classe `LoggerService`.
    -   Fournis une implémentation spécifique (par exemple `DevLoggerService`) pour ce token.
        ```ts
        providers: [
          { provide: LOGGER_TOKEN, useClass: DevLoggerService }
        ]
        ```

3.  **Injecter le Logger avec le Token**
    -   Dans le constructeur du `SupervisionComponent`, injecte le logger en utilisant le `LOGGER_TOKEN`.
        ```ts
        logger = inject(LOGGER_TOKEN);
        ```

4.  **Utiliser le Logger**
    -   Appelle la méthode `log()` comme précédemment.
    -   Observe que le `DevLoggerService` est maintenant utilisé, affichant `[DEV]` dans la console. Cela démontre que l'injection par token permet de découpler complètement le composant de l'implémentation concrète du service.

5.  **Utiliser le Logger dans un autre composant**
    - tester le logger avec une autre implémentation dans un autre composant


## 🧩 Exercice 3 : Utiliser une implémentation de l'interface LOGGER via une factory

Utiliser une implémentation du service de LOG au niveau globale (de l'application). L'implémentation sera conditionner selon une configuration de l'environnement de BUILD. Vous utiliserez toujours l'injection par token. Cette fois-ci vous devez utiliser une fonction factory avec useClass.

### 💡 Concepts utilisés :

* `chargement par InjectionToken`
* `useFactory`
* `inject`


1.  **Créer une fonction `factory`**
    -   Dans `app.config.ts`, crée une fonction `loggerFactory` qui retourne une instance de `DevLoggerService` ou `ProdLoggerService` en fonction de la valeur de `environment.production`.
    -   Utilise `inject()` à l'intérieur de la factory pour obtenir les instances des services.
        ```ts
        export function loggerFactory() {
          return . . .
        }
        ```

2.  **Fournir le Logger avec `useFactory`**
    -   Dans le tableau `providers` de `appConfig`, ajoute un nouvel objet pour fournir le `LOGGER_TOKEN`.
    -   Utilise la propriété `useFactory` pour lier le token à la fonction `loggerFactory` que tu viens de créer.
        ```ts
        {
          provide: . . .,
          useFactory: . . .
        }
        ```

3.  **Supprimer le Provider local**
    -   Dans `supervision.ts`, supprime le tableau `providers` du décorateur `@Component`. Le composant utilisera maintenant le `provider` global défini dans `app.config.ts`.

4.  **Vérifier le comportement**
    -   Lance l'application en mode développement (`npm start`). Le `SupervisionComponent` devrait logger avec le préfixe `[DEV]`.
    -   Lance l'application en mode production (`ng serve --configuration production`). Le `SupervisionComponent` devrait maintenant logger avec le préfixe `[PROD]`.


## 🧩 Exercice 4 : Ajouter un service ApimConfiguration (asynchrone) pour conditionner les logs

### 🎯 Objectif :

Rendre la configuration du niveau de log dynamique en la récupérant d'un service asynchrone, et factoriser la logique commune des loggers dans une classe de base.

### 💡 Concepts utilisés :

*   Héritage de classe
*   `toSignal` pour convertir un `Observable` en `Signal`
*   `computed` pour dériver un état

### 📝 Enoncé :

1.  **Créer le `ApiManagementService`**
    -   Crée un service `ApiManagementService` qui simule la récupération d'une configuration depuis une API.
    -   Ce service doit avoir une méthode `getApimConfiguration()` qui retourne un `Observable<APimConfiguration>`.
    -   L'interface `APimConfiguration` doit contenir une propriété optionnelle `logLevel`.

2.  **Créer une classe de base `BaseLogger`**
    -   Crée une classe abstraite `BaseLogger` qui implémente l'interface `Logger`.
    -   Injecte `ApiManagementService` dans cette classe de base.
    -   Utilise `toSignal` pour convertir l'observable de configuration en un signal `config`.
    -   Crée un signal `computed` `logLevel` qui dérive le niveau de log à partir du signal `config`.
    -   Déclare une méthode abstraite `log(message: string)`.

3.  **Refactoriser les services de Logger**
    -   Fais hériter `LoggerService`, `DevLoggerService`, et `ProdLoggerService` de la nouvelle classe `BaseLogger`.
    -   Supprime la logique dupliquée de récupération de la configuration de chaque service.
    -   Implémente la méthode `log` dans chaque service pour qu'elle affiche le préfixe correspondant (`[LoggerService]`, `[DEV]`, `[PROD]`) tout en respectant le `logLevel` hérité de la classe de base.

4.  **Vérifier le comportement**
    -   Modifie le `logLevel` dans le `mockConfig` de `ApiManagementService` (par exemple, mets-le à `'info'`).
    -   Comme la condition dans les méthodes `log` est `if (this.logLevel() === 'log')`, les messages ne devraient plus s'afficher.
    -   Remets le `logLevel` à `'log'` pour confirmer que les messages s'affichent à nouveau.
