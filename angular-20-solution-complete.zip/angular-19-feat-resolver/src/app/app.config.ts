import { ApplicationConfig, inject, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

import { routes } from './app.routes';
import { LOGGER_TOKEN } from './infrastructure/interfaces/logger';
import { DevLoggerService } from './infrastructure/services/dev-logger-service';
import { ProdLoggerService } from './infrastructure/services/prod-logger-service';
import { environment } from '../environments/environment';

export function loggerFactory() {
  return environment.production ? inject(ProdLoggerService) : inject(DevLoggerService);
}

export const appConfig: ApplicationConfig = {
  providers: [
    provideAnimationsAsync(),
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    {
      provide: LOGGER_TOKEN,
      useFactory: loggerFactory
    }
  ]
};
