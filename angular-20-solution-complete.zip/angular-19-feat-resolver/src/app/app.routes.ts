import { Routes } from '@angular/router';
import { permitApplicationsResolver } from './application/permit-management/resolvers/permit-applications.resolver';

export const routes: Routes = [
  {
    path: 'accueil',
    loadComponent: () => import('./application/home/home').then(m => m.Home)
  },
  {
    path: 'demandes-permis',
    loadComponent: () => import('./application/permit-application/pages/permit-application/permit-application').then(m => m.PermitApplicationPage)
  },
  {
    path: 'affectation-vehicule',
    loadComponent: () => import('./application/vehicle-assignment/pages/vehicle-assignment/vehicle-assignment').then(m => m.VehicleAssignment)
  },
  {
    path: 'dashboard',
    loadComponent: () => import('./application/dashboard/pages/dashboard/dashboard').then(m => m.Dashboard)
  },
  {
    path: 'gestion-permis',
    loadComponent: () => import('./application/permit-management/pages/permit-management/permit-management').then(m => m.PermitManagement),
    resolve: {
      applications: permitApplicationsResolver
    }
  },
  {
    path: 'validation-permis',
    loadComponent: () => import('./application/permit-management/pages/permit-validation/permit-validation').then(m => m.PermitValidationPage),
    resolve: {
      applications: permitApplicationsResolver
    }
  },
  {
    path: 'parametres',
    loadComponent: () => import('./application/settings/pages/settings/settings').then(m => m.SettingsPage)
  }
];
