import { Injectable } from '@angular/core';
import { delay, Observable, of } from 'rxjs';


export interface APimConfiguration {
  url: string;
  apiKey: string;
  logLevel?: string; // Optionnel, pour la configuration du niveau de log
}

@Injectable({
  providedIn: 'root'
})
export class ApiManagementService {

  private mockConfig: APimConfiguration = {
    url: 'https://api.example.com',
    apiKey: '12345-ABCDE',
    logLevel: 'info' // Niveau de log par défaut
  };

  constructor() { }

  getApimConfiguration(): Observable<APimConfiguration> {
      // Simule une latence réseau de 500ms
      return of(this.mockConfig).pipe(delay(1000));
    }
}
