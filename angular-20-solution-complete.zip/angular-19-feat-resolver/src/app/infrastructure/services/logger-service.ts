import { Injectable } from '@angular/core';
import { BaseLogger } from './base-logger.service';

@Injectable({
  providedIn: 'root',
})
export class LoggerService extends BaseLogger {
  log(message: string) {
    if (this.logLevel() === 'log') {
      console.log('[LoggerService] ', message);
    }
  }
}
