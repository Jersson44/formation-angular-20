import { Injectable } from '@angular/core';
import { BaseLogger } from './base-logger.service';

@Injectable({
  providedIn: 'root',
})
export class DevLoggerService extends BaseLogger {
  log(message: string) {
    if (this.logLevel() === 'log') {
      console.log('[DEV] ', message);
    }
  }
}
