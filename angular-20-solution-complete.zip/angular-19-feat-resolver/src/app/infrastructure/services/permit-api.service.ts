import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { PermitApplication } from '../../domain/permit-management/models/permit-application';

@Injectable({
  providedIn: 'root'
})
export class PermitApiService {

  private mockData: PermitApplication[] = [
    { id: 1, type: 'résident', demandeur: 'Alice', status: 'en_attente' },
    { id: 2, type: 'professionnel', demandeur: 'Bob', status: 'en_attente' },
    { id: 3, type: 'visiteur', demandeur: 'Claire', status: 'approuve' },
    { id: 4, type: 'résident', demandeur: 'David', status: 'en_attente' },
    { id: 5, type: 'professionnel', demandeur: 'Eva', status: 'rejete' },
    { id: 6, type: 'visiteur', demandeur: 'François', status: 'en_attente' },
    { id: 7, type: 'résident', demandeur: 'Gina', status: 'en_attente' },
    { id: 8, type: 'professionnel', demandeur: 'Hugo', status: 'en_cours' },
    { id: 9, type: 'visiteur', demandeur: 'Isabelle', status: 'en_attente' },
    { id: 10, type: 'résident', demandeur: 'Jacques', status: 'approuve' },
    { id: 11, type: 'professionnel', demandeur: 'Katia', status: 'en_attente' },
    { id: 12, type: 'visiteur', demandeur: 'Louis', status: 'en_attente' },
    { id: 13, type: 'résident', demandeur: 'Marie', status: 'rejete' },
    { id: 14, type: 'professionnel', demandeur: 'Nicolas', status: 'en_attente' },
    { id: 15, type: 'visiteur', demandeur: 'Olivia', status: 'en_cours' },
    { id: 16, type: 'résident', demandeur: 'Paul', status: 'en_attente' },
    { id: 17, type: 'professionnel', demandeur: 'Quentin', status: 'approuve' },
    { id: 18, type: 'visiteur', demandeur: 'Rosa', status: 'en_attente' },
    { id: 19, type: 'résident', demandeur: 'Sophie', status: 'en_attente' },
    { id: 20, type: 'professionnel', demandeur: 'Thomas', status: 'rejete' }
  ];

  constructor() { }

  getPermitApplications(): Observable<PermitApplication[]> {
    console.log('-- PermitApiService : Fetching permit applications from mock data...');

    // Simule une latence réseau de 500ms
    return of(this.mockData).pipe(delay(1000));
  }
}
