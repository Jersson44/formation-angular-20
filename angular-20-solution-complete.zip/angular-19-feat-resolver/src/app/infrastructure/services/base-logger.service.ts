import { computed, inject, Injectable } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ApiManagementService } from './api-management.service';
import { Logger } from '../interfaces/logger';

@Injectable()
export abstract class BaseLogger implements Logger {
  // -- injection de dépendances
  private apimConfig = inject(ApiManagementService);
  // -- membres
  protected config = toSignal(this.apimConfig.getApimConfiguration());
  protected logLevel = computed(() => {
    return this.config()?.logLevel || 'log';
  });

  abstract log(message: string): void;
}
