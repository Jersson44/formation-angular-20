import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  isDarkTheme = signal(true); // Thème sombre par défaut

  constructor() {
    // Appliquer le thème au démarrage en fonction des préférences du navigateur
    const prefersLight = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
    this.setDarkTheme(!prefersLight);
  }

  setDarkTheme(isDark: boolean): void {
    this.isDarkTheme.set(isDark);
    if (isDark) {
      document.body.classList.add('dark-theme');
      document.body.classList.remove('light-theme');
    } else {
      document.body.classList.add('light-theme');
      document.body.classList.remove('dark-theme');
    }
  }
}
