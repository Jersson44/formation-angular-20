import { InjectionToken } from "@angular/core";

export interface Logger {
  log(message: string): void;
}

export const LOGGER_TOKEN = new InjectionToken<Logger>('LoggerToken');
