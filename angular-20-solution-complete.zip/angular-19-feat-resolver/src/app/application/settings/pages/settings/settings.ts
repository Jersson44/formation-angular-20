import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ThemeService } from '../../../../infrastructure/services/theme.service';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, MatSlideToggleModule],
  templateUrl: './settings.html',
  styleUrl: './settings.scss'
})
export class SettingsPage {
  themeService = inject(ThemeService);

  toggleTheme(event: { checked: boolean; }): void {
    this.themeService.setDarkTheme(event.checked);
  }
}
