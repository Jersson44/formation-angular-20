import { Component } from '@angular/core';
import { Supervision } from "../../components/supervision/supervision";

@Component({
  selector: 'app-dashboard',
  imports: [Supervision],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss'
})
export class Dashboard {

}
