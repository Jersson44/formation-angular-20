import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Dashboard } from './dashboard';
import { Supervision } from '../../components/supervision/supervision';
import { LOGGER_TOKEN } from '../../../../infrastructure/interfaces/logger';
import { DevLoggerService } from '../../../../infrastructure/services/dev-logger-service';

describe('Dashboard', () => {
  let component: Dashboard;
  let fixture: ComponentFixture<Dashboard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Dashboard, Supervision],
      providers: [{ provide: LOGGER_TOKEN, useClass: DevLoggerService }],
    }).compileComponents();

    fixture = TestBed.createComponent(Dashboard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
