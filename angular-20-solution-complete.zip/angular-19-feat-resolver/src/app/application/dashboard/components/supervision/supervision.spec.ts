import { render, screen } from '@testing-library/angular';
import { Supervision } from './supervision';
import { LOGGER_TOKEN } from '../../../../infrastructure/interfaces/logger';
import { DevLoggerService } from '../../../../infrastructure/services/dev-logger-service';
import { DashboardStateService } from '../../services/dashboard-state.service';
import { signal } from '@angular/core';

describe('Supervision', () => {
  it('devrait afficher les informations de supervision', async () => {
    const state = {
      chargement: signal(false),
      demandesEnCours: signal(5),
      vehiculesDisponibles: signal(10),
      utilisateursActifs: signal(15),
    };

    await render(Supervision, {
      providers: [
        { provide: LOGGER_TOKEN, useClass: DevLoggerService },
        { provide: DashboardStateService, useValue: state },
      ],
    });

    expect(screen.getByText('Demandes: 5')).toBeInTheDocument();
    expect(screen.getByText('Véhicules dispo: 10')).toBeInTheDocument();
    expect(screen.getByText('Utilisateurs: 15')).toBeInTheDocument();
  });

  it("devrait afficher un message de chargement", async () => {
    const state = {
      chargement: signal(true),
      demandesEnCours: signal(0),
      vehiculesDisponibles: signal(0),
      utilisateursActifs: signal(0),
    };

    await render(Supervision, {
      providers: [
        { provide: LOGGER_TOKEN, useClass: DevLoggerService },
        { provide: DashboardStateService, useValue: state },
      ],
    });

    expect(screen.getByText('Chargement...')).toBeInTheDocument();
  });
});
