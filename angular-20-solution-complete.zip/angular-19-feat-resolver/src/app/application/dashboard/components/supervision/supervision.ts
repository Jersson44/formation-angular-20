import { Component, inject } from '@angular/core';
import { LOGGER_TOKEN } from '../../../../infrastructure/interfaces/logger';
import { DevLoggerService } from '../../../../infrastructure/services/dev-logger-service';
import { DashboardStateService } from '../../services/dashboard-state.service';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-supervision',
  imports: [MatButtonModule, MatIconModule],
  templateUrl: './supervision.html',
  styleUrl: './supervision.scss'
})
export class Supervision {
  state = inject(DashboardStateService);
  logger = inject(LOGGER_TOKEN);

  constructor() {
    this.logger.log('Supervision component initialized');
  }
}
