import { Component } from '@angular/core';

@Component({
  selector: 'app-notification',
  imports: [],
  template: `<div class="badge-status" ><ng-content/></div>`,
  styleUrl: './notification.scss',
})
export class Notification {

  status: 'success' | 'error' = 'success';
}
