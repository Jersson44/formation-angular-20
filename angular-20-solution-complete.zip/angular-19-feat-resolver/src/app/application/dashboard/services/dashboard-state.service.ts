import { computed, effect, Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DashboardStateService {

  demandesEnCours = signal(120);
  vehiculesDisponibles = signal(3);
  utilisateursActifs = signal(42);
  chargement = signal(true);

  surcharge = computed(() =>
    this.vehiculesDisponibles() < 5 && this.demandesEnCours() > 100
  );

  constructor() {
    setTimeout(() => {
      this.chargement.set(false);
    }, 3000);

    effect(() => {
      if (this.surcharge()) {
        console.warn('⚠️ Surcharge détectée dans le système !');
      }
    });
  }
}
