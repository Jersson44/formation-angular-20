import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-vehicle-assignment',
  imports: [],
  templateUrl: './vehicle-assignment.html',
  styleUrl: './vehicle-assignment.scss',
})
export class VehicleAssignment {
  affectation = signal({ agent: '', vehicule: '' });
  messageErreur = 'Ce véhicule n\'est plus disponible.';
  hasErreur = signal<boolean>(false);

  changerAgent(event: Event) {
    const input = event?.target as HTMLInputElement;
    this.affectation.update((affectation) => ({ ...affectation, agent: input.value }));
    console.log(`-- Agent modifié : ${this.affectation().agent}`);
  }

  changerVehicule(event: Event) {
    const input = event?.target as HTMLInputElement;
    this.affectation.update((affectation) => {

      if (input.value === 'FR-999-LI') {
        this.hasErreur.set(true);
        affectation.vehicule = '';
        return affectation;
      }
      this.hasErreur.set(false);
      return { ...affectation, vehicule: input.value };
    });
    console.log(`-- Véhicule modifié : ${this.affectation().vehicule}`);
  }
}
