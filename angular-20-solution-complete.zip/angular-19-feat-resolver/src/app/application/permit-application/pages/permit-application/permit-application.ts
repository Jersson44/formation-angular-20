import { Component, inject } from '@angular/core';
import { PermitApplicationForm } from "../../components/permit-application-form/permit-application-form";
import { LOGGER_TOKEN } from '../../../../infrastructure/interfaces/logger';
import { ProdLoggerService } from '../../../../infrastructure/services/prod-logger-service';

@Component({
  selector: 'app-permit-application-page',
  standalone: true,
  imports: [PermitApplicationForm],
  templateUrl: './permit-application.html',
  styleUrl: './permit-application.scss',
  providers: [
    {
      provide: LOGGER_TOKEN, useClass: ProdLoggerService
    }
  ],
})
export class PermitApplicationPage {

  private logger = inject(LOGGER_TOKEN);
  constructor() {
    this.logger.log('PermitApplicationPage component initialized');
  }

}
