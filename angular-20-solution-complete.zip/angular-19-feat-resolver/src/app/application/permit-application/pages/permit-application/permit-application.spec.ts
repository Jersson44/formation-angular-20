import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PermitApplicationPage } from './permit-application';
import { PermitStore } from '../../../permit-management/services/permit-store';
import { PermitApplicationForm } from '../../components/permit-application-form/permit-application-form';

describe('PermitApplicationPage', () => {
  let component: PermitApplicationPage;
  let fixture: ComponentFixture<PermitApplicationPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PermitApplicationPage, PermitApplicationForm],
      providers: [PermitStore],
    }).compileComponents();

    fixture = TestBed.createComponent(PermitApplicationPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
