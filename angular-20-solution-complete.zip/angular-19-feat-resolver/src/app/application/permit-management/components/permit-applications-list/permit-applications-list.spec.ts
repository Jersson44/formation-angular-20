import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PermitApplicationsList } from './permit-applications-list';

describe('PermitApplicationsList', () => {
  let component: PermitApplicationsList;
  let fixture: ComponentFixture<PermitApplicationsList>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PermitApplicationsList]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PermitApplicationsList);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
