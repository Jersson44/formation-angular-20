import { Component, computed, inject, input, InputSignal, signal, WritableSignal, output } from '@angular/core';
import { PermitStore } from '../../services/permit-store';
import { PermitApplication } from '../../../../domain/permit-management/models/permit-application';

@Component({
  selector: 'app-permit-applications-list',
  imports: [],
  templateUrl: './permit-applications-list.html',
  styleUrl: './permit-applications-list.scss'
})
export class PermitApplicationsList {

  // -- params -- inputs / outputs
  public maxDemandesAffichees: InputSignal<number> = input.required<number, number>({
    transform: (value: number) => {
      if (value < 5) {
        console.warn(`-- maxDemandesAffichees doit être >= 5, valeur fournie : ${value}`);
        return 5;
      }
      return value;
    }
  });
  public applicationSelected = output<PermitApplication>();

  // -- services -- injection dependances
  private permitStore = inject(PermitStore);

  // -- membres
  public permitApplications = this.permitStore.permitApplications;

  public loading = computed(() => this.permitApplications.status() === 'loading');
  public error = computed(() => this.permitApplications.error());
  public demandes = computed(() => this.permitApplications.value() ?? []);

  private filtre = signal<string>('');

  private demandesFiltrees = computed(() => {
    const type = this.filtre();
    return type ? this.demandes().filter(d => d.type === type) : this.demandes();
  });

  // -- méthodes
  public demandesAffichees = computed(() => {
    const max = this.maxDemandesAffichees();
    return this.demandesFiltrees().slice(0, max);
  });

  public changeFiltre(event: Event): void {
    const input = event?.target as HTMLInputElement;
    console.log(`-- Filtre modifié : ${input.value}`);
    this.filtre.set(input.value);
  }

  public selectApplication(application: PermitApplication): void {
    this.applicationSelected.emit(application);
  }
}
