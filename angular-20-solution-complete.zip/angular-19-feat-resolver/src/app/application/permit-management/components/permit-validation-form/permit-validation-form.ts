import { Component, effect, inject, input, InputSignal, model, ModelSignal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { PermitApplication } from '../../../../domain/permit-management/models/permit-application';

@Component({
  selector: 'app-permit-validation-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './permit-validation-form.html',
  styleUrl: './permit-validation-form.scss'
})
export class PermitValidationForm {
  public application: InputSignal<PermitApplication> = input.required<PermitApplication>();
  public status: ModelSignal<string> = model<string>('');
  public validationForm: FormGroup;

  private fb = inject(FormBuilder);

  constructor() {
    this.validationForm = this.fb.group({
      id: [''],
      status: ['', Validators.required],
      comments: ['']
    });

    effect(() => {
      const app = this.application();
      if (app && app.id != this.validationForm.value.id) {
        this.validationForm.patchValue({
          id: app.id,
          status: app.status,
          comments: '' // Reset comments on new application
        });
      }

      console.log('--- PermitValidationForm - status mis à jour :', this.status());
    });
  }

  onSubmit(): void {
    if (this.validationForm.valid) {
      console.log('Formulaire soumis :', {
        applicationId: this.application().id,
        ...this.validationForm.value
      });

      this.status.set(this.validationForm.value.status);
      // Ici, vous appelleriez un service pour mettre à jour la demande
    }
  }
}
