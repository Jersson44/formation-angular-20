import { Component, computed, effect, linkedSignal, model, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PermitApplicationsList } from '../../components/permit-applications-list/permit-applications-list';
import { PermitValidationForm } from '../../components/permit-validation-form/permit-validation-form';
import { PermitApplication } from '../../../../domain/permit-management/models/permit-application';
import { Notification } from '../../../dashboard/components/notification/notification';

@Component({
  selector: 'app-permit-validation',
  standalone: true,
  imports: [CommonModule, PermitApplicationsList, PermitValidationForm, Notification],
  templateUrl: './permit-validation.html',
  styleUrl: './permit-validation.scss'
})
export class PermitValidationPage {
  public selectedApplication = signal<PermitApplication | null>(null);
  public currentStatus = linkedSignal(() => {
    console.log('--- PermitValidationPage - currentStatus recalculé');

    return this.selectedApplication()?.status || ''
  });

  //public currentStatus = model('Aucun statut sélectionné');

  constructor() {

    effect(() => {
      console.log('-- EFFECT : Statut courant mise à jour :', this.currentStatus());
    });

    /*this.currentStatus.subscribe((status) => {
      console.log('-- Statut courant changé :', status);
    });*/
    // Initialisation ou logique supplémentaire si nécessaire
  }

  onApplicationSelected(application: PermitApplication): void {
    console.log('-- Application sélectionnée :', application);
    this.selectedApplication.set(application);
  }
}
