import { Component, signal } from '@angular/core';
import { PermitApplicationsList } from "../../components/permit-applications-list/permit-applications-list";

@Component({
  selector: 'app-permit-management',
  imports: [PermitApplicationsList],
  templateUrl: './permit-management.html',
  styleUrl: './permit-management.scss'
})
export class PermitManagement {
  public maxDemandesAffichees = signal<number>(10);
  public readonly numbers = Array.from({length: 20}, (_, i) => i + 1);

  setMaxDemandesAffichees(event: Event): void {
    const input = event?.target as HTMLInputElement;
    this.maxDemandesAffichees.set(input.value ? parseInt(input.value, 10) : 10);
    console.log(`-- Nombre maximum de demandes affichées modifié : ${this.maxDemandesAffichees()}`);
  }
}
