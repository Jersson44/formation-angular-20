import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PermitManagement } from './permit-management';

describe('PermitManagement', () => {
  let component: PermitManagement;
  let fixture: ComponentFixture<PermitManagement>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PermitManagement]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PermitManagement);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
