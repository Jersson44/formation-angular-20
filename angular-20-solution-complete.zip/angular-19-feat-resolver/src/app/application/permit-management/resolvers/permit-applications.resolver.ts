import { inject } from '@angular/core';
import { ResolveFn } from '@angular/router';
import { PermitStore } from '../services/permit-store';

export const permitApplicationsResolver: ResolveFn<any> = () => {
  const permitStore = inject(PermitStore);
  permitStore.nonce.set(Date.now());
  return true;
};
