import { inject, Injectable, resource, signal } from '@angular/core';
import { PermitApiService } from '../../../infrastructure/services/permit-api.service';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PermitStore {
  private permitApiService = inject(PermitApiService);

  public nonce = signal(Date.now());
  public permitApplications = resource({
    params: this.nonce,
    loader: ({
      params
    }) => {
      console.log(`-- Chargement des demandes de permis avec nonce : ${params}`);
      return firstValueFrom(this.permitApiService.getPermitApplications());
    },
  });
}
