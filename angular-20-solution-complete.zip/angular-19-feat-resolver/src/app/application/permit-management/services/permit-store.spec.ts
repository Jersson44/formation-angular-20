import { TestBed } from '@angular/core/testing';

import { PermitStore } from './permit-store';

describe('PermitStore', () => {
  let service: PermitStore;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PermitStore);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
