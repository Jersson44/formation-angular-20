export interface PermitApplication {
  id: number;
  type: 'résident' | 'professionnel' | 'visiteur';
  demandeur: string;
  status: 'en_attente' | 'en_cours' | 'approuve' | 'rejete';
}
